#include <iostream>
#include "Tas.h"

using namespace std;


// ====================
//  TAS ET TRI PAR TAS
// ====================

void afficher(int n, int* T)
{
  // A compléter
} 

bool estTasMax(int n, int* T)
{
  return false; // A modifier...
}

bool estTasMin(int n, int* T)
{
  return false; // A modifier...
}

void tableauManuel(int n, int* T)
{
  // A compléter
}

void tableauAleatoire(int n, int* T, int m, int M)
{
  // A compléter
}

void entasser(int n, int* T, int i)
{
  // A compléter
}

void tas(int n, int* T)
{
  // A compléter
}

int* trier(int n, int* T)
{
  int* Ttrie;
  return Ttrie; // A modifier...
}

void trierSurPlace(int n, int* T)
{
  // A compléter
}

