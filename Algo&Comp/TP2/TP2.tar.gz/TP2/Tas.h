#include <iostream>

using namespace std;

void afficher(int, int*);
bool estTasMax(int, int*);
bool estTasMin(int, int*);
void tableauManuel(int, int*);
void tableauAleatoire(int, int*, int, int);
void entasser(int, int*, int);
void tas(int, int*);
int* trier(int, int*);
void trierSurPlace(int, int*);


